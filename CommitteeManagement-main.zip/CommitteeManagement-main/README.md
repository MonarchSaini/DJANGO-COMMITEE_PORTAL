#CommitteeManagement
This is a Committee Portal for Colleges
based on Django Framework

modules required:
asgiref==3.8.1
Django==5.0.3
pillow==10.2.0
sqlparse==0.4.4
tzdata==2024.1
